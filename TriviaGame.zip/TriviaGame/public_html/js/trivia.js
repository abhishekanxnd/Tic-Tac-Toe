/*  The main script file that makes the index.html page dynamic and functional.
 *  Name: Abhishek Anand, Student ID: 991592067
 */

const question = document.getElementById("question");
const choices = Array.from(document.getElementsByClassName("choice-text"));
const progressText = document.getElementById("progressText");
const scoreText = document.getElementById("score");
const progressBarFull = document.getElementById("progressBarFull");
let currentQuestion = {};
let acceptingAnswers = false;
let score = 0;
let questionCounter = 0;
let availableQuesions = [];

let questions = [
    {
        question: "Who won the World Cup in 2014?",
        choice1: "Argentina",
        choice2: "France",
        choice3: "Portugal",
        choice4: "Germany",
        answer: 4
    },
    {
        question: "Who plays Iron-Man?",
        choice1: "Chris Hemsworth",
        choice2: "Chris Evans",
        choice3: "Robert Downey Jr.",
        choice4: "Ben Affleck",
        answer: 3
    },
    {
        question: "What country won the very first FIFA World Cup in 1930?",
        choice1: "Germany",
        choice2: "Brazil",
        choice3: "Uruguay",
        choice4: "Argentina",
        answer: 3
    },
    {
        question: "Who is often called the father of the computer?",
        choice1: "Ada Lovelace",
        choice2: "Blaise Pascal",
        choice3: "William 'Bill' Moggridge",
        choice4: "Charles Babbage",
        answer: 4
    },
    {
        question: "What was Twitter's original name?",
        choice1: "twttr",
        choice2: "tweetbook",
        choice3: "Odeo",
        choice4: "tweeter",
        answer: 1
    },
    {
        question: "Which planet is the hottest in the solar system?",
        choice1: "Jupiter",
        choice2: "Mercury",
        choice3: "Sun",
        choice4: "Venus",
        answer: 4
    },
    {
        question: "Which planet has the most gravity?",
        choice1: "Saturn",
        choice2: "Earth",
        choice3: "Jupiter",
        choice4: "Uranus",
        answer: 3
    },
    {
        question: "Which company owns Bugatti, Lamborghini. Audi, Porsche and Ducati?",
        choice1: "BMW Group",
        choice2: "Volkswagen",
        choice3: "Mercedes-Benz",
        choice4: "GM",
        answer: 2
    },
    {
        question: "Who is often credited with creating the world’s first car?",
        choice1: "Enzo Ferrari",
        choice2: "Henry Ford",
        choice3: "Carl Benz",
        choice4: "Nikola Tesla",
        answer: 3
    },
    {
        question: "Which country invented tea?",
        choice1: "England",
        choice2: "India",
        choice3: "China",
        choice4: "Japan",
        answer: 3
    }
];

//CONSTANTS
const CORRECT_BONUS = 10;
const MAX_QUESTIONS = 10;

function startGame() {
    questionCounter = 0;
    score = 0;
    availableQuesions = [...questions];
    getNewQuestion();
}

function getNewQuestion() {
    if (availableQuesions.length === 0 || questionCounter >= MAX_QUESTIONS) {
        //go to the end page
        window.alert("Your final score is: " + score + "%");
        return window.location.assign("endpage.html");
    }
    questionCounter++;
    progressText.innerText = "Question " + questionCounter + "/" + MAX_QUESTIONS;
    //Update the progress bar
    progressBarFull.style.width = ((questionCounter / MAX_QUESTIONS) * 100) + "%";

    const questionIndex = Math.floor(Math.random() * availableQuesions.length);
    currentQuestion = availableQuesions[questionIndex];
    question.innerText = currentQuestion.question;

    choices.forEach(choice => {
        const number = choice.dataset["number"];
        choice.innerText = currentQuestion["choice" + number];
    });

    availableQuesions.splice(questionIndex, 1);
    acceptingAnswers = true;
}
;

choices.forEach(choice => {
    choice.addEventListener("click", e => {
        if (!acceptingAnswers)
            return;

        acceptingAnswers = false;
        const selectedChoice = e.target;
        const selectedAnswer = selectedChoice.dataset["number"];

        const classToApply =
                selectedAnswer == currentQuestion.answer ? "correct" : "incorrect";

        if (classToApply === "correct") {
            incrementScore(CORRECT_BONUS);
        }

        selectedChoice.parentElement.classList.add(classToApply);

        setTimeout(() => {
            selectedChoice.parentElement.classList.remove(classToApply);
            getNewQuestion();
        }, 1000);
    });
});

function incrementScore(num) {
    score += num;
    scoreText.innerText = score;
}

startGame();