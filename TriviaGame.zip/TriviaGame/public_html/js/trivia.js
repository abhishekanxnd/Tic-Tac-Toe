/*  The main script file that makes the index.html page dynamic and functional.
 *  Name: Abhishek Anand, Student ID: 991592067
 */

//Referencing elements from html file and storing them in variables.
const question = document.getElementById("question");
const choices = Array.from(document.getElementsByClassName("choice-text"));  //Create an array of referenced elements
const progressText = document.getElementById("progressText");                //later used in displaying question number and progress bar
const scoreText = document.getElementById("score");                          //later used in displaying current score which is dynamically incremented for every correct(MATCHING) answer 
const progressBarFull = document.getElementById("progressBarFull");          //controls width of progress bar so that it increases by a specific percentage 
let currentQuestion = {};                                                    //variable declaration
let acceptingAnswers = false;                                                //
let score = 0;                                                               // variable initialization
let questionCounter = 0;                                                     //
let availableQuesions = [];                                                  //

//creating an array of questions, choices/options and correct answers
let questions = [
    {
        question: "Who won the World Cup in 2014?",
        choice1: "Argentina",
        choice2: "France",
        choice3: "Portugal",
        choice4: "Germany",
        answer: 4
    },
    {
        question: "Who plays Iron-Man?",
        choice1: "Chris Hemsworth",
        choice2: "Chris Evans",
        choice3: "Robert Downey Jr.",
        choice4: "Ben Affleck",
        answer: 3
    },
    {
        question: "What country won the very first FIFA World Cup in 1930?",
        choice1: "Germany",
        choice2: "Brazil",
        choice3: "Uruguay",
        choice4: "Argentina",
        answer: 3
    },
    {
        question: "Who is often called the father of the computer?",
        choice1: "Ada Lovelace",
        choice2: "Blaise Pascal",
        choice3: "William 'Bill' Moggridge",
        choice4: "Charles Babbage",
        answer: 4
    },
    {
        question: "What was Twitter's original name?",
        choice1: "twttr",
        choice2: "tweetbook",
        choice3: "Odeo",
        choice4: "tweeter",
        answer: 1
    },
    {
        question: "Which planet is the hottest in the solar system?",
        choice1: "Jupiter",
        choice2: "Mercury",
        choice3: "Sun",
        choice4: "Venus",
        answer: 4
    },
    {
        question: "Which planet has the most gravity?",
        choice1: "Saturn",
        choice2: "Earth",
        choice3: "Jupiter",
        choice4: "Uranus",
        answer: 3
    },
    {
        question: "Which company owns Bugatti, Lamborghini. Audi, Porsche and Ducati?",
        choice1: "BMW Group",
        choice2: "Volkswagen",
        choice3: "Mercedes-Benz",
        choice4: "GM",
        answer: 2
    },
    {
        question: "Who is often credited with creating the world’s first car?",
        choice1: "Enzo Ferrari",
        choice2: "Henry Ford",
        choice3: "Carl Benz",
        choice4: "Nikola Tesla",
        answer: 3
    },
    {
        question: "Which country invented tea?",
        choice1: "England",
        choice2: "India",
        choice3: "China",
        choice4: "Japan",
        answer: 3
    }
];

//declaring and intializing the points for correct answers and maximum number of questions
const CORRECT_BONUS = 10;
const MAX_QUESTIONS = 10;

//starts the game
function startGame() {
    questionCounter = 0;
    score = 0;
    //using the spread operator on 'questions' array to get available questions
    availableQuesions = [...questions];
    //function call to get a random question from the array of questions
    getNewQuestion();
}

//randomly chooses a question out of array of questions using the index of array elements
function getNewQuestion() {
    if (availableQuesions.length === 0 || questionCounter >= MAX_QUESTIONS) {
        //go to the end page
        window.alert("Your final score is: " + score + "%");
        return window.location.assign("endpage.html");
    }
    questionCounter++;
    progressText.innerText = "Question " + questionCounter + "/" + MAX_QUESTIONS;
    //Updates the width of progress bar by editing the width property of css, hence the % is required at end 
    progressBarFull.style.width = ((questionCounter / MAX_QUESTIONS) * 100) + "%";

    //randomly generate an index and show the question in the array with that index on the html page
    const questionIndex = Math.floor(Math.random() * availableQuesions.length);
    currentQuestion = availableQuesions[questionIndex];
    question.innerText = currentQuestion.question;

    //use the 'data-number' attribute in the html file to reference the choices/options, and respectively show the options for the current question(with randomly generated index)
    choices.forEach(choice => {
        const number = choice.dataset["number"];
        choice.innerText = currentQuestion["choice" + number];
    });

    //remove the chosen question from the available questions array so it won't be repeated again later on
    availableQuesions.splice(questionIndex, 1);
    //Allows choosing an option, switched from false to true when question, options are displayed on html page
    acceptingAnswers = true;
}

//when an option is clicked on by user, other options are disabled(acceptingAnswers becomes false), but if it was already set to false, the function is exited
choices.forEach(choice => {
    choice.addEventListener("click", e => {
        if (!acceptingAnswers)
            return;

        //the selected option is then compared with answer (having a number string value) defined in the questions array 
        acceptingAnswers = false;
        const selectedChoice = e.target;
        const selectedAnswer = selectedChoice.dataset["number"];

        //a ternary conditional operator is used here which is equivalent to if-else. The evaluation of this is stored in variable classToApply.
        const classToApply = selectedAnswer == currentQuestion.answer ? "correct" : "incorrect";

        //function to increment score is called if classToApply evaluates to true or the value "correct"
        if (classToApply === "correct") {
            incrementScore(CORRECT_BONUS);
        }

        //The container element containing the text user clicked on as the selected choice, the class that is defined in the container tag, this is applied to that class 
        selectedChoice.parentElement.classList.add(classToApply);
        //when this is done, the original class is kept as well so we need to remove that or the color coding and incrementation won't work properly
        //example: <div class="choice-container" correct incorrect">
        //                                          ^        ^
        //                                      original   after evaluation     
 
        //this function is used to cause a delay between an option is chosen and the next randomly generated question is displayed. 
        //This delay is required to show the user if their chosen option is correct or incorrect (by color coding the container button, done using css)
        setTimeout(() => {
            //we just want the class to show until color(red/green; wrong/right) is shown to the user and then move to the next question
            //so we remove the class now
            selectedChoice.parentElement.classList.remove(classToApply);
            //and after removing we immediately call the function to generate a new question
            getNewQuestion();
        }, 1000); //here, a delay of 1000 milliseconds is enough to show the user whether they answered correctly.
    });
});

//this function is used to increment score with the value initialized in varaible CORRECT_BONUS whenever user's selected choice evaluates to "correct"
function incrementScore(num) {
    score += num;
    //this score is shown in the element referenced by class "score"
    scoreText.innerText = score;
}

//function call to start the game
startGame();