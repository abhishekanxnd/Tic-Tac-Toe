/*Abhishek Anand*/

const question = document.getElementById("question");
const choices = Array.from(document.getElementsByClassName("choice-text"));
const progressText = document.getElementById("progressText");
const scoreText = document.getElementById("score");
const progressBarFull = document.getElementById("progressBarFull");
let currentQuestion = {};
let acceptingAnswers = false;
let score = 0;
let questionCounter = 0;
let availableQuesions = [];

let questions = [
  {
    question: "Who won the World Cup in 2014?",
    choice1: "Argentina",
    choice2: "France",
    choice3: "Portugal",
    choice4: "Germany",
    answer: 4
  },
  {
    question: "Who played as Iron-Man",
    choice1: "Chris Hemsworth",
    choice2: "Chris Evans",
    choice3: "Robert Downey Jr.",
    choice4: "Ben Affleck",
    answer: 3
  },
  {
    question: "How do you say Hello in Korean",
    choice1: "gamsahamnida",
    choice2: "annyeonghaseyo",
    choice3: "annyeong",
    choice4: "saranghayeo",
    answer: 2
  },
  {
    question: "How is IU & SUGA's latest collab",
    choice1: "The best",
    choice2: "Nostalgic",
    choice3: "28",
    choice4: "Mainstream",
    answer: 1
  },
  {
    question: "What's up",
    choice1: "Trying to finish this assignment lol",
    choice2: "Hoping not to breach integrity again",
    choice3: "Hoping for good marks",
    choice4: "I will work harder",
    answer: 2
  }
];

//CONSTANTS
const CORRECT_BONUS = 1;
const MAX_QUESTIONS = 5;

function startGame() {
  questionCounter = 0;
  score = 0;
  availableQuesions = [...questions];
  getNewQuestion();
}

function getNewQuestion() {
  if (availableQuesions.length === 0 || questionCounter >= MAX_QUESTIONS) {
    //go to the end page
    outputScore();
  }
  questionCounter++;
  progressText.innerText = "Question " + questionCounter + "/" + MAX_QUESTIONS;
  //Update the progress bar
  progressBarFull.style.width = ((questionCounter / MAX_QUESTIONS) * 100) + "%";

  const questionIndex = Math.floor(Math.random() * availableQuesions.length);
  currentQuestion = availableQuesions[questionIndex];
  question.innerText = currentQuestion.question;

  choices.forEach(choice => {
    const number = choice.dataset["number"];
    choice.innerText = currentQuestion["choice" + number];
  });

  availableQuesions.splice(questionIndex, 1);
  acceptingAnswers = true;
};

choices.forEach(choice => {
  choice.addEventListener("click", e => {
    if (!acceptingAnswers) return;

    acceptingAnswers = true;
    const selectedChoice = e.target;
    const selectedAnswer = selectedChoice.dataset["number"];

    
    if(selectedAnswer === currentQuestion.answer) {
        var classToApply = "correct)";
    } else {
        classToApply = "incorrect";
    }

    if (classToApply === "correct") {
      incrementScore(CORRECT_BONUS);
    }

    selectedChoice.parentElement.classList.add(classToApply);

    setTimeout(() => {
      selectedChoice.parentElement.classList.remove(classToApply);
      getNewQuestion();
    }, 1000);
  });
});

function incrementScore (num) {
  score += num;
  scoreText.innerText = score;
}

function outputScore() {
    window.alert("Your final score is: " + score);
    window.location.replace("endpage.html");
}

startGame();







